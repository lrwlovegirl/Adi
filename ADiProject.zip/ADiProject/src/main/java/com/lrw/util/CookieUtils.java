package com.lrw.util;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * ��������cookie�ķ�����request������Ϊ�����ñ���cookie��·��
 * @author Administrator
 *
 */
public class CookieUtils {
   public static void save(HttpServletResponse response,HttpServletRequest request,String name,String value){
	    Cookie c= new Cookie(name,value);
	    c.setMaxAge(3600);//ʧЧʱ��ͳһ����Ϊ1Сʱ
	    c.setPath(request.getContextPath());
	    response.addCookie(c);
   }
   
   public static Map<String,String> load(HttpServletRequest request){
	   Map<String,String> map = new HashMap<String, String>();
	   Cookie c[] =request.getCookies();
	   if(c!=null){
	   for(int x=0;x<c.length;x++){
		   map.put(c[x].getName(), c[x].getValue());
	     }
	   }
	   System.out.println(c);
	   return map;
   }
   }
