package com.lrw.interceptor;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;

import com.lrw.service.MemberService;
import com.lrw.util.CookieUtils;
import com.lrw.vo.Member;

public class LoginInterceptor implements HandlerInterceptor {
    @Resource
	private MemberService memberservice;
 	
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object obj)
		throws Exception {
	  System.out.println("----------------------------------");
	  System.out.println(memberservice);
	  HttpSession ses= request.getSession();
		if(ses.getAttribute("username")==null){//���ڻ�û�е�¼��
			Map<String,String> map =CookieUtils.load(request);
			if(map.containsKey("username")&&map.containsKey("password")){
				Member vo = new Member();
				vo.setUsername(map.get("username"));
				vo.setPassword(map.get("password"));
				try {
					if(this.memberservice.login(vo)!=null){
						ses.setAttribute("username", vo.getUsername());
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} 
	  return true;
	
  }
}

